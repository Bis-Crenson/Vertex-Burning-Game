Use any Java program, open Main.java and feel free to change the levels and rounds
levels will change how many vertices there are(3^levels + 1)
rounds will change how many times the game is played
If you get a package error, just delete the package com.company in every class.
Enjoy!!
package com.company;
//This will be the Vertex Class
/*
Created 10/21/2020
Modified 10/21/2020, 10/22/2020, 10/25/2020
Last Modified 10/25/2020
Author: Chris Benson
Main function:
*****************
- Used exclusively for Branches
- A simple object that can hold four values
    * Who currently owns the vertex, 0 being neutral, and 1-2 being the players
    * Vertex ID number, used to identify which vertex number is in the branch.
    * Determine if this circle will be burned, if so, then it will be burned to the appropriate player.
- Getters and Setters for those values
- Two methods for getting closest first and second child
- One methods for getting closest parent
- Method for resetting burn variables
 */
public class Vertex {
    //Private variables
    private int playerID = 0;
    private int vertexID, playerBurn;
    private boolean burnable = false; //Auto set to false, will be changed in BurnVertex.

    //Default constructor
    public Vertex(){
        //Empty
    }

    //Getters
    public int getPlayerID(){
        return playerID;
    }
    public int getVertexID(){
        return vertexID;
    }
    public int getPlayerBurn(){
        return playerBurn;
    }
    public boolean getBurnable(){
        return burnable;
    }

    //Setters
    public void setPlayerID(int playerID){
        this.playerID = playerID;
    }
    public void setVertexID(int vertexID){
        this.vertexID = vertexID;
    }
    public void setPlayerBurn(int playerBurn){
        this.playerBurn = playerBurn;
    }
    public void setBurnable(boolean burnable){
        this.burnable = burnable;
    }

    //Closest and Second Closest child methods
    public int getChildOne(){
        return vertexID * 3 + 1; //0 will be 1
    }
    public int getChildTwo(){
        return vertexID * 3 + 2 ; //0 will be 2
    }
    public int getChildThree(){
        return vertexID * 3 + 3 ; //0 will be 3
    }

    //Get current Parent
    public int getParent(){
        double temp = Math.ceil(vertexID/3.0 - 1); //The formula I used needed a ceiling function.
        int parent = (int)temp; //convert to int
        if(parent <= 0) //If the parent is less than 0, always return 0.
            return 0;
        return parent;
    }

    public void resetBurn(){
        burnable = false;
        playerBurn = 0;
    }
/*
As of 10/21/2020, this class is complete.
 */
}


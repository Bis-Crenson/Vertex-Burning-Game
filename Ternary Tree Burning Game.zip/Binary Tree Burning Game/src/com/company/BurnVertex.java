package com.company;
//This will be the Burn Vertex Class
/*
Created 10/21/2020
Modified 10/21/2020, 10/22/2020, 10/25/2020, 2/25/2021 3/2/2021, 3/15/2021, 3/17/2021, 3/19/2020
Last Modified 3/19/2020
Author: Chris Benson
Main function:
*****************
- Used in Branch Class
- Main purpose is to burn adjacent vertices
    * Will be determined by Vertex's getChild and getParent methods
    * Will probably be the most complicated part of this program
    * Since VertexID and it's actual index are one off, will need to account for this in this class
- Only checks should come from the getChild and getParent methods
- No player needed since this burn is for both players
- 10/25/2020, adding if statements to check if a burn is already set for a player, if so, delete that burn and set it to 0.
 */
public class BurnVertex{
    //private variable
    Vertex[] object;

    //Default constructor
    public BurnVertex(Vertex[] object){ //Main purpose is to get the Vertex for future use
        this.object = object;
    }

    public void fullBurn(){ //Takes data from setBurnVertices and actually burns.
        for(int i = 0; i < object.length; i++){
            if(object[i].getBurnable() && object[i].getPlayerBurn() != 0){ //If true and has a player number, do the following
                //System.out.println("Test");
                object[i].setPlayerID(object[i].getPlayerBurn()); //Changes player ID to the set burn value
                object[i].resetBurn(); //resets values
                //System.out.println("Vertex " + object[i].getVertexID() + " has been burned for player " + object[i].getPlayerID());
            }
        }
    }

    //burning method, will be fairly complex, will return true when the pre burn is complete, false if an error occurred
    public boolean setBurnVertices(int player, int levels) {
        int otherPlayer;
        if (isArrayFull()) { //Checks to see if the array is full, will continue on with the program if it isn't
            //System.out.println("Array full, no burning can be done");
            return false; //False returned if array is full, no burning has been done.
        }
        if (player==1)
            otherPlayer = 2;
        else
            otherPlayer = 1;
        //Every if statement will need a try/catch, since the getChild checks all numbers, including unborn children.
        for(int i = 0; i < object.length; i++) {//For loop to change possible burnables to true. Change the non [i]'s to the child methods
            try {
                if (object[i].getPlayerID()==0 && ((object[object[i].getChildOne()].getPlayerID()==player) || (object[object[i].getChildTwo()].getPlayerID()==player) || (object[object[i].getChildThree()].getPlayerID()==player) || (object[object[i].getParent()].getPlayerID()==player)) //Long if statment to see if any child or parent are controlled by player 2 or neutral
                        && ((object[object[i].getChildOne()].getPlayerID()!=otherPlayer) && (object[object[i].getChildTwo()].getPlayerID()==otherPlayer) && (object[object[i].getChildThree()].getPlayerID()==otherPlayer) && (object[object[i].getParent()].getPlayerID()!=otherPlayer))) { //Makes sure all children and parents aren't under opposition control
                    object[i].setBurnable(true); //Sets true to burnable
                    object[i].setPlayerBurn(player); //Gives burnable to player
                }
            }
                catch(java.lang.ArrayIndexOutOfBoundsException e){ //Catch only runs during the last level, since the last level doesn't have any children, which throws a Array out of bounds exception
                    if (object[i].getPlayerID()==0 && object[object[i].getParent()].getPlayerID()==player) { //Since no children are present, checks to see if the parent is under player control, if so, burn
                        object[i].setBurnable(true); //Sets true to burnable
                        object[i].setPlayerBurn(player); //Gives burnable to player
                    }
                }
            }
        return true;
    }
           // System.out.println("loop: " + i + "\nplayer: " + player);
//            try { //Try 1, Child one is under player control, and Parent is under player control
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 2, Child two is under player control, and Parent is under player control
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 3, Child three is under player control, and Parent is under player control - NEW
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 3, All children are under player control, and Parent is under player control - NEW
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//
//            /*
//            @TODO: ALL DONE ✔ ✔ ✔ ✔
//            FIRST complicated change, we need 3 separate versions
//            Addition/No Change 1: Already done, Children 1 and 2 are under player control Try 4 ✔
//            Addition 2: Children 1 and 3 are under player control Try 5 ✔
//            Addition 3: Children 2 and 3 are under player control Try 6 ✔
//            Addition 4: All Children are under player control Try 7 ✔
//             */
//            try { //Try 4, children one and two are under player control. - Change 1
//                if(((object[object[i].getChildOne()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 5, children 1 and 3 are under player control.
//                if(((object[object[i].getChildOne()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 6, children 2 and 3 are under player control.
//                if(((object[object[i].getChildTwo()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 7, All children are under player control (Childrens 1, 2, 3)
//                if(((object[object[i].getChildOne()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//        //**************************END FIRST MAJOR BLOCK**************************************************************
//
//            /*
//            @TODO
//            End changes here
//            SECOND complicated change
//            Addition 0: Child one is under player, while child two is neutral Try 8 ✔
//            Addition 1: Child one is under player control, while child three is neutral Try 9 ✔
//            Addition 2: Child two is under player control, while child three is neutral Try 10 ✔
//            Addition 3: Child two is under player control, while child one is neutral Try 11 ✔
//            Addition 4: Child three is under player control, while child one is neutral Try 12 ✔
//            Addition 5: Child three is under player control, while child two is neutral Try 13 ✔
//            CHECK ON THE BOTTOM 6 LATER, DONT THINK THEY'RE NEEDED
//            Addition 6: Child one is neutral, while child two is under player control Try 14
//            Addition 7: Child one is neutral, while child three is under player control Try 15
//            Addition 8: Child two is neutral, while child one is under player control Try 16
//            Addition 9: Child two is neutral, while child three is under player control Try 17
//            Addition 10: Child three is neutral, while child one is under player control Try 18
//            Addition 11: Child three is neutral, while child two is under player control Try 19
//
//
//             */
//            try { //Try 8, Child one is under player, while child two is neutral
//                if(((object[object[i].getChildOne()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 9, Child one is under player control, while child three is neutral
//                if(((object[object[i].getChildOne()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 10, Child two is under player control, while child three is neutral
//                if(((object[object[i].getChildTwo()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 11, Child two is under player control, while child one is neutral
//                if(((object[object[i].getChildTwo()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 12, Child three is under player control, while child one is neutral
//                if(((object[object[i].getChildThree()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 13, Child three is under player control, while child two is neutral
//                if(((object[object[i].getChildThree()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//
//            try { //Try UNKNOWN1, Parent under player control, while child 1 is neutral
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try UNKNOWN2, Parent under player control, while child 2 is neutral
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try UNKNOWN3, Parent under player control, while child 3 is neutral
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try UNKNOWN4, Parent under player control, while all children are neutral
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==0) && (object[object[i].getChildTwo()].getPlayerID()==0) && (object[object[i].getChildThree()].getPlayerID()==0)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try UNKNOWN5, Parent under player control, while child 1 is player control
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try UNKNOWN6, Parent under player control, while child 2 is player control
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try UNKNOWN7, Parent under player control, while child 3 is player control
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try UNKNOWN8, Parent under player control, while all children are player control
//                if(((object[object[i].getParent()].getPlayerID()==player) && (object[object[i].getChildOne()].getPlayerID()==player) && (object[object[i].getChildTwo()].getPlayerID()==player) && (object[object[i].getChildThree()].getPlayerID()==player)) && (object[i].getPlayerID()==0)) {
//                    if(object[i].getBurnable() == true && object[i].getPlayerBurn() == otherPlayer){
//                        object[i].setBurnable(false); //Sets false, since there's a conflict
//                        object[i].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[i].setBurnable(true); //Sets true to burnable
//                        object[i].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//
//
//
//
//        //**************************END SECOND MAJOR BLOCK**************************************************************
//            /*
//            @TODO ✔ ✔ ✔ ✔ ✔ ✔ ✔
//            End changes here
//            THIRD semi-complicated change
//            Modification 1: Add child three to "try 7 - number will change" Try 14 ✔
//            Addition 1: Index is under player control, while child 3 is neutral Try 15 ✔
//             */
//
//
//            try { //Try 14, Current index is under player control, while parent is neutral
//                if((object[object[i].getParent()].getPlayerID()==0) && (object[i].getPlayerID()==player)) { //
//                    if(object[object[i].getParent()].getBurnable() == true && object[object[i].getParent()].getPlayerBurn() == otherPlayer){
//                        object[object[i].getParent()].setBurnable(false); //Sets false, since there's a conflict
//                        object[object[i].getParent()].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[object[i].getParent()].setBurnable(true); //Sets true to burnable
//                        object[object[i].getParent()].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 15, Current index is under player control, while children are neutral
//                if(((object[object[i].getChildOne()].getPlayerID()==0) && (object[object[i].getChildTwo()].getPlayerID()==0) && (object[object[i].getChildThree()].getPlayerID()==0)) && (object[i].getPlayerID()==player)) {
//                    if((object[object[i].getChildOne()].getBurnable() == true && object[object[i].getChildOne()].getPlayerBurn() == otherPlayer) && (object[object[i].getChildTwo()].getBurnable() == true && object[object[i].getChildTwo()].getPlayerBurn() == otherPlayer) && (object[object[i].getChildThree()].getBurnable() == true && object[object[i].getChildThree()].getPlayerBurn() == otherPlayer)){
//                        object[object[i].getChildOne()].setBurnable(false); //Sets true to burnable
//                        object[object[i].getChildTwo()].setBurnable(false); //Sets true to burnable
//                        object[object[i].getChildThree()].setBurnable(false); //Sets true to burnable
//                        object[object[i].getChildOne()].setPlayerBurn(0); //Gives burnable to player
//                        object[object[i].getChildTwo()].setPlayerBurn(0); //Gives burnable to player
//                        object[object[i].getChildThree()].setPlayerBurn(0); //Gives burnable to player
//                    }
//                    else {
//                        object[object[i].getChildOne()].setBurnable(true); //Sets true to burnable
//                        object[object[i].getChildTwo()].setBurnable(true); //Sets true to burnable
//                        object[object[i].getChildThree()].setBurnable(true); //Sets true to burnable
//                        object[object[i].getChildOne()].setPlayerBurn(player); //Gives burnable to player
//                        object[object[i].getChildTwo()].setPlayerBurn(player); //Gives burnable to player
//                        object[object[i].getChildThree()].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 16, Current index is under player control, while children 1 is neutral
//                if((object[object[i].getChildOne()].getPlayerID()==0) && (object[i].getPlayerID()==player)) {
//                    if(object[object[i].getChildOne()].getBurnable() == true && object[object[i].getChildOne()].getPlayerBurn() == otherPlayer){
//                        object[object[i].getChildOne()].setBurnable(false); //Sets false, since there's a conflict
//                        object[object[i].getChildOne()].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[object[i].getChildOne()].setBurnable(true); //Sets true to burnable
//                        object[object[i].getChildOne()].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 17, Current index is under player control, while children 2 is neutral
//                if((object[object[i].getChildTwo()].getPlayerID()==0) && (object[i].getPlayerID()==player)) {
//                    if(object[object[i].getChildTwo()].getBurnable() == true && object[object[i].getChildTwo()].getPlayerBurn() == otherPlayer){
//                        object[object[i].getChildTwo()].setBurnable(false); //Sets false, since there's a conflict
//                        object[object[i].getChildTwo()].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[object[i].getChildTwo()].setBurnable(true); //Sets true to burnable
//                        object[object[i].getChildTwo()].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 18, Current index is under player control, while children 3 is neutral
//                if((object[object[i].getChildThree()].getPlayerID()==0) && (object[i].getPlayerID()==player)) {
//                    if(object[object[i].getChildThree()].getBurnable() == true && object[object[i].getChildThree()].getPlayerBurn() == otherPlayer){
//                        object[object[i].getChildThree()].setBurnable(false); //Sets false, since there's a conflict
//                        object[object[i].getChildThree()].setPlayerBurn(0); //Sets 0, since there's a conflict
//                    }
//                    else {
//                        object[object[i].getChildThree()].setBurnable(true); //Sets true to burnable
//                        object[object[i].getChildThree()].setPlayerBurn(player); //Gives burnable to player
//                    }
//                }
//            }catch(java.lang.ArrayIndexOutOfBoundsException e){
//                //do nothing since it doesn't exist.
//            }
//            //END ALL CHANGES
//        }
//        undoBurns(player, otherPlayer);
//        // System.out.println("Pre-Burn complete");
//        return true;
//    }
//    //**************************END THIRD MAJOR BLOCK**************************************************************
//
//    /*
//    @TODO
//    FOURTH VERY complicated change
//    Addition 1: Current index is neutral, conflicting parent/child three Try 21 ✔
//    Addition 2: Current index is neutral, conflicting children three Try 24 ✔
//    Addition 3: Current index is neutral, conflicts with child 1 and 2 Try 25 ✔
//    Addition 4: Current index is neutral, conflicts with all children 1 and 3 Try 26 ✔
//    Addition 5: Current index is neutral, conflicts with all children 2 and 3 Try 27 ✔
//    Addition 6: Current index is neutral, conflicts with all children Try 28 ✔
//    Addition 7: Children 1 and 2 conflict with the same parent Try 29 ✔
//    Addition 8: Children 1 and 3 conflict with the same parent Try 30 ✔
//    Addition 9: Children 2 and 3 conflict with the same parent Try 31 ✔
//    Addition 10: ALl Children conflict with the same parent Try 32 ✔
//     */
////NEED MORE, NEED OTHERPLAYER AND THEN PLAYER AND VICE VERSEA
//    public void undoBurns(int player, int otherPlayer) {
//        for (int i = 1; i < object.length; i++) {
//            try { //Try 19, current index is neutral, and has conflicting parent/children (conflict with parent/child one)
//                if ((object[object[i].getParent()].getPlayerID()==otherPlayer && object[object[i].getChildOne()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 20, current index is neutral, and has conflicting parent/children (conflict with parent/child two)
//                if ((object[object[i].getParent()].getPlayerID()==otherPlayer && object[object[i].getChildTwo()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 21, current index is neutral, and has conflicting parent/children (conflict with parent/child three)
//                if ((object[object[i].getParent()].getPlayerID()==otherPlayer && object[object[i].getChildThree()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 22, current index is neutral, and has conflicting parent/children (conflict with child one)
//                if ((object[object[i].getChildOne()].getPlayerID()==otherPlayer && object[object[i].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 23, current index is neutral, and has conflicting parent/children (conflict with child two)
//                if ((object[object[i].getChildTwo()].getPlayerID()==otherPlayer && object[object[i].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 24, current index is neutral, and has conflicting parent/children (conflict with child three)
//                if ((object[object[i].getChildThree()].getPlayerID()==otherPlayer && object[object[i].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 25, current index is neutral, and has conflicting children one and children two
//                if ((object[object[i].getChildOne()].getPlayerID()==otherPlayer && object[object[i].getChildTwo()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 26, current index is neutral, and has conflicting children one and children three
//                if ((object[object[i].getChildOne()].getPlayerID()==otherPlayer && object[object[i].getChildThree()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 27, current index is neutral, and has conflicting children two and children three
//                if ((object[object[i].getChildTwo()].getPlayerID()==otherPlayer && object[object[i].getChildThree()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 28, current index is neutral, and has conflicting children one, two and children three
//                if ((object[object[i].getChildOne()].getPlayerID()==otherPlayer && object[object[i].getChildTwo()].getPlayerID()==player && object[object[i].getChildThree()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 29, children 1 and 2 are conflicted with the same parent. Objectception
//                if ((object[object[object[i].getChildOne()].getParent()].getPlayerID()==otherPlayer && object[object[object[i].getChildTwo()].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 30, children 1 and 3 are conflicted with the same parent. Objectception
//                if ((object[object[object[i].getChildOne()].getParent()].getPlayerID()==otherPlayer && object[object[object[i].getChildThree()].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 31, children 2 and 3 are conflicted with the same parent. Objectception
//                if ((object[object[object[i].getChildTwo()].getParent()].getPlayerID()==otherPlayer && object[object[object[i].getChildThree()].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 32, all children are conflicted with the same parent. Objectception -Might have to do this one 2-3 times to account for variation?
//                if ((object[object[object[i].getChildOne()].getParent()].getPlayerID()==otherPlayer && object[object[object[i].getChildTwo()].getParent()].getPlayerID()==player && object[object[object[i].getChildThree()].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 33, all children are conflicted with the same parent. Objectception
//                if ((object[object[object[i].getChildOne()].getParent()].getPlayerID()==player && object[object[object[i].getChildTwo()].getParent()].getPlayerID()==otherPlayer && object[object[object[i].getChildThree()].getParent()].getPlayerID()==player) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//            try { //Try 34, all children are conflicted with the same parent. Objectception
//                if ((object[object[object[i].getChildOne()].getParent()].getPlayerID()==player && object[object[object[i].getChildTwo()].getParent()].getPlayerID()==player && object[object[object[i].getChildThree()].getParent()].getPlayerID()==otherPlayer) && object[i].getPlayerID()==0) {
//                    object[i].setBurnable(false);
//                    object[i].setPlayerBurn(0);
//                }
//            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//                //do nothing since it doesn't exist.
//            }
//        }
//    }

    //Same method as ComputerPlayer, will be useful for determining if the array is full.
    public boolean isArrayFull(){ //Array full refers to there being no 0's left.
        for(int i = 0; i < object.length; i++)//Goes through entire array
            if(object[i].getPlayerID() == 0)
                return false; //Only returns false if there's a player ID that is still 0
        return true; //Returns true if there aren't any 0's left.
    }
}



//Use this for a normal game
//            if((object[i - 1].getPlayerID() == player) && (object[i + 1].getPlayerID() == player) && (object[i].getPlayerID() == 0)){ //Long if statement checking to see if both left and right are owned by current player
//                    object[i].setBurnable(true); //Sets true to burnable
//                    object[i].setPlayerBurn(player); //Gives burnable to player 1
//                    }
//            if((object[i - 1].getPlayerID() == player) && (object[i + 1].getPlayerID() != otherPlayer) && (object[i].getPlayerID() == 0)){ //Long  if checking if the left is owned by player 1 and that the right isn't owned by anyone
//                    object[i].setBurnable(true); //Sets true to burnable
//                    object[i].setPlayerBurn(player); //Gives burnable to player 1
//                    }
//                    if((object[i - 1].getPlayerID() != otherPlayer) && (object[i + 1].getPlayerID() == player) && (object[i].getPlayerID() == 0)){ //Same as above, but checks right instead of left
//                    object[i].setBurnable(true); //Sets true to burnable
//                    object[i].setPlayerBurn(player); //Gives burnable to player 1
//                    }
//                    if(object[i-1].getPlayerID() == 0 && object[i].getPlayerID() == player){ //If the object is index 0, and to the right is the player, then set burn to true
//                    object[i-1].setBurnable(true); //Sets true to burnable
//                    object[i-1].setPlayerBurn(player); //Gives burnable to player 1
//                    }
//                    if(object[object.length - 1].getPlayerID() == 0 && object[object.length - 2].getPlayerID() == player){ //Same as above, but for the end of the array.
//                    object[object.length - 1].setBurnable(true); //Sets true to burnable
//                    object[object.length -1].setPlayerBurn(player); //Gives burnable to player 1
//                    }
package com.company;

//This will be the Branch Class
/*
Created 10/25/2020
Modified 10/25/2020
Last Modified 10/25/2020
Author: Chris Benson
Main function:
- Run the game
- Use a for loop for each game
- Display the average # of wins/losses/ties
*****************

 */
public class Game {
    //private variables
    private int gamesPlayed, levels, gameLoops; //Game loops is used for the for loop, determines how many games to play.
    private int p1Wins, p2Wins, ties;
    Branch branch;
    //default constructor, has levels as a parameter
    public Game(int levels, int gameLoops){
        this.levels = levels;
        this.gameLoops = gameLoops;
        this.branch = new Branch(this.levels);
    }
    //Play game uses a for loop determined by the constructor, will then display the average wins/losses/ties
    public void playGame(){
        for(int i = 0; i < gameLoops; i++){
            branch.playGame();
            getStatistics();
            System.out.println("Game: " + (i+1));
            System.out.println("Player 1 average wins: " + (float)p1Wins/gameLoops * 100 + "%");
            System.out.println("Player 2 average wins: " + (float)p2Wins/gameLoops * 100 + "%");
            System.out.println("Average ties: " + (float)ties/gameLoops * 100 + "%");
            //Once the above is complete, create a new branch object
            this.branch = new Branch(this.levels);
        }
    }
    //Get stats gets the player win, so it can be divided by the gameLoops.
    private void getStatistics(){
        int p1Score = branch.getP1Score();
        int p2Score = branch.getP2Score();
        if(p1Score > p2Score)
            this.p1Wins++;
        else if(p1Score < p2Score)
            this.p2Wins++;
        else
            this.ties++;
    }
}

package com.company;
//Not much to say, it's the driver class.
public class Main {
    public static void main(String[] args) {
        Game game = new Game(1,1000);
        game.branch.assignVertexID();
        game.playGame();
        //game.branch.displayBranch();
    }
}

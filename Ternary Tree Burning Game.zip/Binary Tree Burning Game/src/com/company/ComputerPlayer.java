package com.company;
//This will be the Computer Play Class
/*
Created 10/21/2020
Modified 10/21/2020, 10/22/2020, 10/25/2020
Last Modified 10/25/2020
Author: Chris Benson
Main function:
*****************
- Used exclusively for a Branch class
- Will use random input, 0-totalVertices, or rand.nextInt(totalVertices)
    * Check to see if this circle is owned by other player
    * If, continue random input until new circle is taken
- Player number will be determine by constructor, two player objects will be made for Game.
- Method to determine if entire array is already full(No 0's remain)
*/

import java.util.Random;

public class ComputerPlayer {
    //Private variables
    private int playerNumber; //Player identification
    private Random rand = new Random(); //Random object
    private Vertex[] object;
    //Default Constructor
    public ComputerPlayer(int playerNumber, Vertex[] object){ //Only purpose is to set the player number and get the vertex object
        this.playerNumber = playerNumber;
        this.object = object;
    }

    //Determine if the random value is already owned, will change index to player number if true and return true
    public boolean playerTurn(){
        while(!isArrayFull()){ //While loop ONLY runs when there's available space.
            int randomChoice = returnRandInput(); //Always gets a new random choice
            if(object[randomChoice].getPlayerID() != 0) //Checks to see if the vertex is owned
                doNothing();//System.out.println("This vertex is occupied by player " + object[randomChoice].getPlayerID());
            else if(object[randomChoice].getPlayerID() == 0){ //Checks to see if the vertex is 0, if so, it's yours!
                //System.out.println("Vertex " + object[randomChoice].getVertexID() + " is free, now under player's " + playerNumber + " control.");
                object[randomChoice].setPlayerID(playerNumber); //Sets playerID to your player number
                return true; //Does nothing, but ends the loop.
            }
        }
        //System.out.println("No more available vertices, ending.");
        return false; //Does nothing but state nothing was added.
    }

    //Determine if the array has any spaces left
    public boolean isArrayFull(){ //Array full refers to there being no 0's left.
        for(int i = 0; i < object.length; i++)//Goes through entire array
            if(object[i].getPlayerID() == 0)
                return false; //Only returns false if there's a player ID that is still 0
            return true; //Returns true if there aren't any 0's left.
    }
    //Rand method
    public int returnRandInput(){ //Main purpose is to return a random value between 0 and Vertex.length
        return rand.nextInt(object.length);
    }
    public void doNothing(){ //Just to fill in for empty if statement.
        //yup
    }
}

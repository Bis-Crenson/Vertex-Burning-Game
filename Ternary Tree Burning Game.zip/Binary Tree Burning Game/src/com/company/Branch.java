package com.company;

import java.util.Arrays;
//This will be the Branch Class
/*
Created 10/21/2020
Modified 10/21/2020, 10/25/2020
Last Modified 10/25/2020
Author: Chris Benson
Main function:
*****************
- Used exclusively for the Binary Object
- Have a vertexAmount variable, nothing stored until constructor.
- Array of Vertices, size determined by levels
    * Levels determined in code
    * Size will be determined by the following formula:
        # 2^Level, math.pow(2,level)
        # Level >= 0
        # Uses for loop and does math.pow for each level.
    * Standard Array rules apply (Start at 0)
- For loop will assign vertexID to every object in the array.
    * Will be a method
    * Player ID will NOT get a +1 for simplistic sake.
    * Also create each element.
-Display numbers as if it was a binary tree(Not Ternary, I copied 99% of the code from Binary and used it for Ternary)
    *S lightly complex formula for figuring this out
     Take 4 levels, 0,1,2,3
     1
     2-3
     4-5-6-7
     8-9-10-11-12-13-14-15 (Notice there's a pattern, 8 * 2 = 16, minus one = 15, this works for all of sets.
     Take the first number of the level, double it, and take one away, that's the pattern for figuring out which numbers
     are present.)
     This works, but I changed the formula to use 0-14 instead of 1-15, formula is in the Vertex class(Child1,2,Parent)
    * The # of vertices in each level can be found by taking 2 by the power of the current level. Level 3 will be 2^3 or 8.
- Haven't yet decided if the comparison will be in branch or another method.
 */
public class Branch {
    //Private variables
    private Vertex[] vertices;
    private int vertexAmount, levels;
    private ComputerPlayer player1;
    private ComputerPlayer player2;
    private BurnVertex burn;
    private int p1Score, p2Score;
    //Testing ComputerPlayer Class
    //default constructor, will be using the Level formula
    public Branch(int levels){
        this.levels = levels;
        for(int i = 0; i <= this.levels; i++)
            vertexAmount += (int)Math.pow(3, i); //Uses the formula provided in the class description
        vertices = new Vertex[vertexAmount]; //Sets Vertex Array size to the vertexAmount
        assignVertexID(); //Assigns each index of the array to an Vertex object
        player1 = new ComputerPlayer(1, vertices);
        player2 = new ComputerPlayer(2, vertices);
        burn = new BurnVertex(vertices);
    }
    public void playGame(){ //Plays game
        System.out.println("Starting Game: ");
        //displayBranch();
        while(!isArrayFull()){ //Using the array to determine how long the while loop runs
            //displayBranchID();
            //Player 1's turn
            player1.playerTurn();
            //Player 2's turn
            player2.playerTurn();
            //Finalize burns
            //displayBranchID();
            //System.out.println("\n");
            burn.setBurnVertices(1, levels);
            burn.setBurnVertices(2, levels);
            burn.fullBurn();
            //displayBranchID();
            //System.out.println("\n");
        }
        System.out.println("");
        System.out.println("**********");
        System.out.println("Game Over, Displaying Final Results.");
        //displayBranchID();
        p1Score = getPlayerScore(1);
        p2Score = getPlayerScore(2);
        System.out.println("Player 1 has " + p1Score + " vertices.");
        System.out.println("Player 2 has " + p2Score + " vertices.");
        if(p1Score > p2Score)
            System.out.println("Player 1 wins!");
        else if(p1Score < p2Score)
            System.out.println("Player 2 wins!");
        else
            System.out.println("it's a tie!");
//        System.out.println("Player 1 average wins: " + (float)p1Score / vertices.length * 100);
//        System.out.println("Player 2 average wins: " + (float)p2Score / vertices.length * 100);
//        System.out.println("Tie average: " + (float)p1Score / vertices.length * 100);
    }

    //give ID's to the vertices
    public void assignVertexID(){
        for(int i = 0; i < vertices.length; i++){ //For loop will create each element and set the ID.
            vertices[i] = new Vertex(); //Creates new element
            vertices[i].setVertexID(i); //Sets the ID, +1 from i.
        }
    }
    //Display the vertices as a binary tree(loosely)
    public void displayBranch(){ //Finally got it to work!!!!!!
        try {
            int x = 0;
            for (int i = 0; i <= levels; i++) { //Slowly go up until the level value is hit
                for (int j = (int)Math.pow(3, i); j > 0; j--) { //First -1 so 0 is taken into account, 2 to the power of 0 is still 1, so the -1 is needed.
                    System.out.print(vertices[x].getVertexID() + "-");
                    x ++;
                }//Above, noticed a pattern for each level and the number they go up to, so if there's 8 vertices in level 3, the number will be 8-15(8 * 2 - 1)
                System.out.println("");//Separate each number
            }
        }catch(java.lang.ArrayIndexOutOfBoundsException e){
            //Do nothing
        }
    }
    public void displayBranchID(){
        try {
            int x = 0;
            for (int i = 0; i <= levels; i++) { //Slowly go up until the level value is hit
                for (int j = (int)Math.pow(3, i); j > 0; j--) { //First -1 so 0 is taken into account, 2 to the power of 0 is still 1, so the -1 is needed.
                    System.out.print(vertices[x].getPlayerID() + "-");
                    x ++;
                }//Above, noticed a pattern for each level and the number they go up to, so if there's 8 vertices in level 3, the number will be 8-15(8 * 2 - 1)
                System.out.println("");//Separate each number
            }
        }catch(java.lang.ArrayIndexOutOfBoundsException e){
            //Do nothing
        }
    }
    //Determine if the array has any spaces left
    public boolean isArrayFull(){ //Array full refers to there being no 0's left.
        for(int i = 0; i < vertices.length; i++)//Goes through entire array
            if(vertices[i].getPlayerID() == 0)
                return false; //Only returns false if there's a player ID that is still 0
        return true; //Returns true if there aren't any 0's left.
    }
    //Get a player's score
    public int getPlayerScore(int player){
        int score = 0;
        for(int i = 0; i < vertices.length; i++)
            if(vertices[i].getPlayerID() == player) //Increases score by 1 if player is equal to a vertex player ID.
                score++;
        return score;
    }
    //returns the p1 score
    public int getP1Score(){
        return p1Score;
    }
    //returns the p2 score
    public int getP2Score(){
        return p2Score;
    }
}//End of class bracket
